#include<iostream>
#include "task3_l3.h"
#include"task3_l4.h"



int main() {
}